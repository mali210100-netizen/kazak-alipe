import { Router, type IRouter } from "express";
import healthRouter from "./health";
import learningRouter from "./learning";
import progressRouter from "./progress";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(learningRouter);
router.use(progressRouter);
router.use(adminRouter);

export default router;
