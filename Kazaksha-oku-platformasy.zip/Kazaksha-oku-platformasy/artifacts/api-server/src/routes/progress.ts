import { getAuth } from "@clerk/express";
import { countDistinct, eq } from "drizzle-orm";
import { Router, type IRouter, type Request } from "express";
import {
  GetProgressResponse,
  GetSubscriptionResponse,
  RecordProgressBody,
  RecordProgressResponse,
} from "@workspace/api-zod";
import {
  db,
  learnerProfilesTable,
  progressEventsTable,
  storiesTable,
} from "@workspace/db";
import { letters, words } from "../data/learning";
import { ensureStoriesSeeded } from "./learning";

const router: IRouter = Router();
const TRIAL_DAYS = 7;

function getLearnerId(req: Request): string | null {
  const signedInUserId = getAuth(req).userId;
  if (signedInUserId) return signedInUserId;
  const deviceId = req.get("x-learner-id")?.trim();
  return deviceId && deviceId.length <= 128 ? `device:${deviceId}` : null;
}

async function getOrCreateProfile(learnerId: string) {
  const startedAt = new Date();
  const endsAt = new Date(startedAt.getTime() + TRIAL_DAYS * 86_400_000);
  await db
    .insert(learnerProfilesTable)
    .values({ learnerId, trialEndsAt: endsAt })
    .onConflictDoNothing();
  const [profile] = await db
    .select()
    .from(learnerProfilesTable)
    .where(eq(learnerProfilesTable.learnerId, learnerId))
    .limit(1);
  if (!profile) throw new Error("Could not load learner profile.");
  return profile;
}

function toAlmatyDate(value: Date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Almaty",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(value);
  const fields = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${fields.year}-${fields.month}-${fields.day}`;
}

async function summarize(learnerId: string) {
  await ensureStoriesSeeded();
  const events = await db
    .select({
      itemType: progressEventsTable.itemType,
      itemId: progressEventsTable.itemId,
      completedAt: progressEventsTable.completedAt,
    })
    .from(progressEventsTable)
    .where(eq(progressEventsTable.learnerId, learnerId));
  const storiesCount = await db
    .select({ value: countDistinct(storiesTable.id) })
    .from(storiesTable);

  const completedLetters = new Set(
    events.filter((event) => event.itemType === "letter").map((event) => event.itemId),
  ).size;
  const completedWords = new Set(
    events.filter((event) => event.itemType === "word").map((event) => event.itemId),
  ).size;
  const completedStories = new Set(
    events.filter((event) => event.itemType === "story").map((event) => event.itemId),
  ).size;
  const activeDays = new Set(events.map((event) => toAlmatyDate(event.completedAt)));
  const today = toAlmatyDate(new Date());
  let streakDays = 0;
  const reference = new Date(`${activeDays.has(today) ? today : toPreviousDate(today)}T00:00:00.000Z`);
  for (let offset = 0; offset < 366; offset += 1) {
    const day = new Date(reference.getTime() - offset * 86_400_000)
      .toISOString()
      .slice(0, 10);
    if (!activeDays.has(day)) break;
    streakDays += 1;
  }

  const level = Math.min(5, Math.floor(completedStories / 20) + 1);
  return {
    completedLetters,
    totalLetters: letters.length,
    completedStories,
    totalStories: Number(storiesCount[0]?.value ?? 0),
    completedWords,
    streakDays,
    level,
  };
}

function toPreviousDate(date: string) {
  const [year, month, day] = date.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day - 1)).toISOString().slice(0, 10);
}

router.get("/progress", async (req, res) => {
  const learnerId = getLearnerId(req);
  if (!learnerId) {
    res.status(400).json({ message: "Learner ID is required." });
    return;
  }
  const data = await summarize(learnerId);
  res.json(GetProgressResponse.parse(data));
});

router.post("/progress/events", async (req, res) => {
  const learnerId = getLearnerId(req);
  if (!learnerId) {
    res.status(400).json({ message: "Learner ID is required." });
    return;
  }

  const parsed = RecordProgressBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Learning item information is invalid." });
    return;
  }
  const { itemType, itemId } = parsed.data;
  const itemExists =
    itemType === "letter"
      ? letters.some((item) => item.id === itemId)
      : itemType === "word"
        ? words.some((item) => item.id === itemId)
        : Boolean(
            await db
              .select({ id: storiesTable.id })
              .from(storiesTable)
              .where(eq(storiesTable.id, itemId))
              .limit(1)
              .then((rows) => rows[0]),
          );
  if (!itemExists) {
    res.status(404).json({ message: "Learning item was not found." });
    return;
  }

  await db
    .insert(progressEventsTable)
    .values({ learnerId, itemType, itemId })
    .onConflictDoNothing();
  const data = await summarize(learnerId);
  res.json(RecordProgressResponse.parse(data));
});

router.get("/subscription", async (req, res) => {
  const learnerId = getLearnerId(req);
  if (!learnerId) {
    res.status(400).json({ message: "Learner ID is required." });
    return;
  }
  const profile = await getOrCreateProfile(learnerId);
  const status =
    profile.subscriptionStatus === "trialing" &&
    profile.trialEndsAt.getTime() <= Date.now()
      ? "expired"
      : profile.subscriptionStatus;
  const data = {
    status,
    trialStartedAt: profile.trialStartedAt.toISOString(),
    trialEndsAt: profile.trialEndsAt.toISOString(),
    monthlyPrice: 1990,
    currency: "KZT",
    nextPaymentAt: profile.nextPaymentAt?.toISOString() ?? null,
  };
  res.json(GetSubscriptionResponse.parse(data));
});

export default router;