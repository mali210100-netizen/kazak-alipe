import { createHash } from "node:crypto";
import OpenAI from "openai";
import { and, eq, ilike, or, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  GenerateSpeechBody,
  GetLettersResponse,
  GetStoriesQueryParams,
  GetStoriesResponse,
  GetTodayStoryResponse,
  GetWordsResponse,
} from "@workspace/api-zod";
import { db, storiesTable } from "@workspace/db";
import { letters, stories, words } from "../data/learning";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const audioCache = new Map<string, Buffer>();
const audioInflight = new Map<string, Promise<Buffer>>();
const MAX_AUDIO_CACHE_ITEMS = 100;
let seedAttempted = false;
let seedPromise: Promise<void> | undefined;

export async function ensureStoriesSeeded() {
  if (seedAttempted) return;
  if (!seedPromise) {
    seedPromise = (async () => {
      const existing = await db
        .select({ id: storiesTable.id })
        .from(storiesTable)
        .limit(1);
      if (existing.length === 0) {
        await db.insert(storiesTable).values(stories).onConflictDoNothing();
      }
      seedAttempted = true;
    })().catch((error) => {
      seedPromise = undefined;
      throw error;
    });
  }
  await seedPromise;
}

async function listStories(filters: {
  level?: number;
  topic?: string;
  q?: string;
}) {
  const conditions = [];
  if (filters.level) conditions.push(eq(storiesTable.level, filters.level));
  if (filters.topic) conditions.push(eq(storiesTable.topic, filters.topic));
  if (filters.q) {
    const pattern = `%${filters.q.replace(/[%_]/g, "\\$&")}%`;
    const search = or(
      ilike(storiesTable.title, pattern),
      ilike(storiesTable.topic, pattern),
      ilike(storiesTable.text, pattern),
    );
    if (search) conditions.push(search);
  }
  return db
    .select()
    .from(storiesTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(storiesTable.level, storiesTable.id);
}

router.get("/learning/letters", (_req, res) => {
  res.json(GetLettersResponse.parse(letters));
});

router.get("/learning/words", (_req, res) => {
  res.json(GetWordsResponse.parse(words));
});

router.get("/stories", async (req, res) => {
  await ensureStoriesSeeded();
  const filters = GetStoriesQueryParams.parse(req.query);
  const data = await listStories(filters);
  res.json(GetStoriesResponse.parse(data));
});

router.get("/stories/today", async (_req, res) => {
  await ensureStoriesSeeded();
  const data = await listStories({});
  if (data.length === 0) {
    res.status(404).json({ message: "No reading stories are available." });
    return;
  }

  const date = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Almaty",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  const [year, month, day] = date.split("-").map(Number);
  const dayNumber = Math.floor(Date.UTC(year, month - 1, day) / 86_400_000);
  const index = ((dayNumber % data.length) + data.length) % data.length;
  res.json(GetTodayStoryResponse.parse(data[index]));
});

async function makeSpeech(text: string): Promise<Buffer> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY is not configured.");

  const client = new OpenAI({ apiKey });
  const response = await client.audio.speech.create({
    model: "gpt-4o-mini-tts",
    voice: "shimmer",
    input: text,
    response_format: "mp3",
    instructions:
      "Speak in clear, fluent Kazakh with a warm, patient teacher's voice. Read slowly and pronounce Kazakh words naturally.",
  });
  return Buffer.from(await response.arrayBuffer());
}

router.post("/audio/tts", async (req, res) => {
  const parsed = GenerateSpeechBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Enter text of up to 5,000 characters." });
    return;
  }
  if (!process.env.OPENAI_API_KEY) {
    res.status(503).json({ message: "Speech service is not configured." });
    return;
  }

  const text = parsed.data.text.trim();
  if (!text) {
    res.status(400).json({ message: "Text cannot be blank." });
    return;
  }

  const cacheKey = createHash("sha256").update(text).digest("hex");
  let audio = audioCache.get(cacheKey);
  let cacheStatus = "hit";
  if (!audio) {
    cacheStatus = "miss";
    let pending = audioInflight.get(cacheKey);
    if (!pending) {
      pending = makeSpeech(text);
      audioInflight.set(cacheKey, pending);
    }
    try {
      audio = await pending;
      if (audioCache.size >= MAX_AUDIO_CACHE_ITEMS) {
        const oldestKey = audioCache.keys().next().value;
        if (oldestKey) audioCache.delete(oldestKey);
      }
      audioCache.set(cacheKey, audio);
    } catch (error) {
      logger.error({ err: error }, "OpenAI speech generation failed");
      res.status(502).json({ message: "Speech could not be generated right now." });
      return;
    } finally {
      audioInflight.delete(cacheKey);
    }
  }

  res
    .status(200)
    .type("audio/mpeg")
    .set("Cache-Control", "private, max-age=3600")
    .set("X-Audio-Cache", cacheStatus)
    .send(audio);
});

export default router;