import { getAuth } from "@clerk/express";
import { eq } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import {
  CreateStoryBody,
  CreateStoryResponse,
  DeleteStoryResponse,
  GetAdminStoriesResponse,
  UpdateStoryBody,
  UpdateStoryParams,
  UpdateStoryResponse,
} from "@workspace/api-zod";
import { db, storiesTable } from "@workspace/db";
import { ensureStoriesSeeded } from "./learning";

const router: IRouter = Router();

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ message: "Sign in to manage learning content." });
    return;
  }
  const adminIds = new Set(
    (process.env.ADMIN_USER_IDS ?? "")
      .split(",")
      .map((id) => id.trim())
      .filter(Boolean),
  );
  if (!adminIds.has(userId)) {
    res.status(403).json({ message: "Administrator access is required." });
    return;
  }
  next();
}

router.get("/admin/stories", requireAdmin, async (_req, res) => {
  await ensureStoriesSeeded();
  const data = await db
    .select()
    .from(storiesTable)
    .orderBy(storiesTable.level, storiesTable.id);
  res.json(GetAdminStoriesResponse.parse(data));
});

router.post("/admin/stories", requireAdmin, async (req, res) => {
  const parsed = CreateStoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Story content is invalid." });
    return;
  }
  const [story] = await db
    .insert(storiesTable)
    .values({ id: crypto.randomUUID(), ...parsed.data })
    .returning();
  res.status(201).json(CreateStoryResponse.parse(story));
});

router.patch("/admin/stories/:id", requireAdmin, async (req, res) => {
  const params = UpdateStoryParams.safeParse(req.params);
  const body = UpdateStoryBody.safeParse(req.body);
  if (!params.success || !body.success || Object.keys(body.data).length === 0) {
    res.status(400).json({ message: "Story update information is invalid." });
    return;
  }
  const [story] = await db
    .update(storiesTable)
    .set({ ...body.data, updatedAt: new Date() })
    .where(eq(storiesTable.id, params.data.id))
    .returning();
  if (!story) {
    res.status(404).json({ message: "Story was not found." });
    return;
  }
  res.json(UpdateStoryResponse.parse(story));
});

router.delete("/admin/stories/:id", requireAdmin, async (req, res) => {
  const params = UpdateStoryParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ message: "Story ID is invalid." });
    return;
  }
  const deleted = await db
    .delete(storiesTable)
    .where(eq(storiesTable.id, params.data.id))
    .returning({ id: storiesTable.id });
  if (deleted.length === 0) {
    res.status(404).json({ message: "Story was not found." });
    return;
  }
  res.status(204).end();
});

export default router;