import { useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  useCreateStory,
  useDeleteStory,
  useGetAdminStories,
  useGetLetters,
  useGetProgress,
  useGetStories,
  useGetSubscription,
  useGetTodayStory,
  useGetWords,
  useRecordProgress,
  useUpdateStory,
  getGetAdminStoriesQueryKey,
  getGetProgressQueryKey,
  getGetStoriesQueryKey,
} from '@workspace/api-client-react';
import { ClerkProvider, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { kkKZ } from '@clerk/localizations';
import {
  ArrowRight, AudioLines, BookOpen, Check, ChevronRight, CircleHelp,
  Flame, Headphones, House, Library, LockKeyhole, LogIn, Pause, Play, Plus,
  Search, Sparkles, Volume2, X, ChartNoAxesColumn, UserRound,
  Trash2, RotateCcw, Pencil, CalendarDays,
} from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

type Story = { id: string; title: string; level: number; topic: string; text: string };
type Letter = { id: string; uppercase: string; lowercase: string; sound: string; exampleWord: string; exampleMeaning: string };
type Word = { id: string; word: string; syllables: string[]; meaning: string };
type Summary = { completedLetters: number; totalLetters: number; completedStories: number; totalStories: number; completedWords: number; streakDays: number; level: number };
type Subscription = { status: string; trialStartedAt: string; trialEndsAt: string; monthlyPrice: number; currency: string; nextPaymentAt?: string | null };

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const speechCache = new Map<string, string>();
let activeAudio: HTMLAudioElement | null = null;
let stopActiveAudio: (() => void) | null = null;
let speechSequence = 0;

function stopSpeech() {
  speechSequence += 1;
  stopActiveAudio?.();
  stopActiveAudio = null;
  if (activeAudio) {
    activeAudio.pause();
    activeAudio.currentTime = 0;
    activeAudio = null;
  }
}

async function speak(text: string, rate = 0.82) {
  const normalized = text.trim();
  if (!normalized) return;
  stopActiveAudio?.();
  const sequence = ++speechSequence;

  try {
    let audioUrl = speechCache.get(normalized);
    if (!audioUrl) {
      const response = await fetch('/api/audio/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: normalized }),
      });
      if (!response.ok) throw new Error(`Speech request failed (${response.status}).`);
      audioUrl = URL.createObjectURL(await response.blob());
      if (speechCache.size >= 100) {
        const oldest = speechCache.keys().next().value;
        if (oldest) {
          const oldUrl = speechCache.get(oldest);
          if (oldUrl) URL.revokeObjectURL(oldUrl);
          speechCache.delete(oldest);
        }
      }
      speechCache.set(normalized, audioUrl);
    }
    if (sequence !== speechSequence) return;

    const audio = new Audio(audioUrl);
    audio.playbackRate = rate;
    activeAudio = audio;
    await new Promise<void>((resolve, reject) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        if (activeAudio === audio) activeAudio = null;
        stopActiveAudio = null;
        resolve();
      };
      const fail = () => {
        if (settled) return;
        settled = true;
        if (activeAudio === audio) activeAudio = null;
        stopActiveAudio = null;
        reject(new Error('Audio playback failed.'));
      };
      audio.addEventListener('ended', finish, { once: true });
      audio.addEventListener('error', fail, { once: true });
      stopActiveAudio = () => {
        audio.pause();
        finish();
      };
      void audio.play().catch(fail);
    });
  } catch {
    if (sequence === speechSequence) {
      window.dispatchEvent(new Event('qazaq-oku-audio-error'));
    }
  }
}

function AudioErrorNotice() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const showError = () => {
      setVisible(true);
      window.setTimeout(() => setVisible(false), 4500);
    };
    window.addEventListener('qazaq-oku-audio-error', showError);
    return () => window.removeEventListener('qazaq-oku-audio-error', showError);
  }, []);
  if (!visible) return null;
  return <div role="alert" className="audio-error-notice">Дыбысты қосу мүмкін болмады. Байланысты тексеріп, қайта көріңіз.</div>;
}

const navItems = [
  { href: '/', label: 'Басты бет', icon: House },
  { href: '/letters', label: 'Әріптер', icon: AudioLines },
  { href: '/syllables', label: 'Буындар', icon: Sparkles },
  { href: '/stories', label: 'Әңгімелер', icon: Library },
  { href: '/progress', label: 'Жетістік', icon: ChartNoAxesColumn },
];

function Brand() {
  return <Link href="/" className="brand" data-testid="link-home-brand"><span className="brand-mark">ә</span><span>оқу<span style={{ color: '#d77f60' }}>.</span></span></Link>;
}

function Header() {
  const [location, setLocation] = useLocation();
  return (
    <>
      <header className="topbar">
        <Brand />
        <nav className="navlinks desktop-nav" aria-label="Негізгі навигация">
          {navItems.map(({ href, label }) => <Link key={href} href={href} className={`navlink ${location === href ? 'active' : ''}`} data-testid={`link-nav-${href.replace('/', '') || 'home'}`}>{label}</Link>)}
        </nav>
        <div className="nav-actions">
          <Link className="btn btn-outline small" href="/profile" data-testid="link-profile"><UserRound className="icon" /> Профиль</Link>
          <Link className="btn btn-primary small" href="/subscription" data-testid="link-plan"><Sparkles className="icon" /> Жоспар</Link>
        </div>
        <div className="mobile-nav">
          <label className="sr-only" htmlFor="mobile-navigation">Бөлімді таңдаңыз</label>
          <select id="mobile-navigation" aria-label="Бөлімге өту" value={location} onChange={(event) => setLocation(event.target.value)} data-testid="select-mobile-navigation">
            {navItems.map((item) => <option key={item.href} value={item.href}>{item.label}</option>)}
            <option value="/profile">Профиль</option>
            <option value="/subscription">Жазылым</option>
          </select>
        </div>
      </header>
      <nav className="mobile-bottom" aria-label="Төменгі навигация">
        {navItems.slice(0, 4).map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`bottom-link ${location === href ? 'active' : ''}`} data-testid={`link-bottom-${href.replace('/', '') || 'home'}`}><Icon className="icon" /><span>{label}</span></Link>)}
        <Link href="/progress" className={`bottom-link ${location === '/progress' ? 'active' : ''}`} data-testid="link-bottom-progress"><ChartNoAxesColumn className="icon" /><span>Жетістік</span></Link>
      </nav>
    </>
  );
}

function PageFrame({ children }: { children: ReactNode }) {
  return <div className="app-shell"><Header />{children}</div>;
}

function PageHead({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return <div className="page-head"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{children}</div></div>;
}

function LoadingState({ label = 'Жүктеліп жатыр…' }: { label?: string }) {
  return <div className="panel" style={{ padding: 22 }} aria-live="polite" data-testid="status-loading"><div className="skeleton" style={{ height: 18, width: '32%', marginBottom: 14 }} /><div className="skeleton" style={{ height: 13, width: '76%', marginBottom: 8 }} /><div className="skeleton" style={{ height: 13, width: '58%' }} /><span className="sr-only">{label}</span></div>;
}

function ErrorState({ retry, message = 'Ақпаратты жүктеу мүмкін болмады.' }: { retry: () => void; message?: string }) {
  return <div className="error-box" role="alert" data-testid="status-error"><strong>{message}</strong><p style={{ margin: '7px 0 14px' }}>Байланысты тексеріп, қайта көріңіз.</p><button className="btn btn-quiet small" onClick={retry} data-testid="button-retry"><RotateCcw className="icon" /> Қайта жүктеу</button></div>;
}

function EmptyState({ title, detail }: { title: string; detail: string }) {
  return <div className="panel empty-state" data-testid="state-empty"><BookOpen className="icon" style={{ margin: '0 auto 12px', width: 26, height: 26, color: '#438778' }} /><strong>{title}</strong><span>{detail}</span></div>;
}

function FooterNote() {
  return <p className="footer-note">Қазақша оқу — күн сайынғы кішкентай қадамнан басталады.</p>;
}

function HomePage() {
  const progress = useGetProgress();
  const today = useGetTodayStory();
  const subscription = useGetSubscription();
  const record = useRecordProgress();
  const [showTodayText, setShowTodayText] = useState(false);
  const summary = progress.data as Summary | undefined;
  const story = today.data as Story | undefined;
  return <PageFrame><main className="page-wrap">
    <section className="hero-grid">
      <div className="panel hero-card"><div className="hero-card-content"><div className="eyebrow">Қазақша оқу әлемі</div><h1>Әріптен — әңгімеге.</h1><p className="lede">42 әріппен танысып, буын құрап, қызықты қысқа мәтіндерді өзің оқы.</p><div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 24 }}><Link href="/letters" className="btn" style={{ background: '#f5c890', color: '#25433d' }} data-testid="link-start-reading">Оқуды бастау <ArrowRight className="icon" /></Link><Link href="/stories" className="btn" style={{ color: '#fff9eb', background: 'rgba(255,255,255,.13)' }} data-testid="link-browse-stories">Әңгімелерді көру</Link></div></div></div>
      <div className="panel hero-aside" style={{ position: 'relative' }}><span className="sticker">КҮНДІК<br />ОҚУ</span><div><span className="pill coral"><CalendarDays className="icon" /> БҮГІНГІ ӘҢГІМЕ</span><div style={{ marginTop: 20 }} className="eyebrow">ОҚУҒА ШАҚЫРАДЫ</div><h2 style={{ maxWidth: 260, margin: '8px 0 10px' }}>{today.isLoading ? 'Бір сәт…' : story?.title || 'Жаңа әңгіме күтіп тұр'}</h2><p style={{ color: '#766e60', lineHeight: 1.55, fontSize: 13, maxWidth: 240 }}>{story?.text ? `${story.text.slice(0, 93)}${story.text.length > 93 ? '…' : ''}` : today.isError ? 'Бүгінгі мәтінді қазір алу мүмкін болмады.' : 'Қысқа мәтінді дауыстап оқып көр.'}</p></div>{story ? <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><button className="btn btn-primary small" onClick={() => setShowTodayText(true)} data-testid="button-open-today-story">Мәтінді оқу <ArrowRight className="icon" /></button><button className="btn btn-quiet btn-icon" onClick={() => speak(story.text)} aria-label="Бүгінгі әңгімені тыңдау" data-testid="button-listen-today-story"><Headphones className="icon" /></button></div> : <Link className="btn btn-secondary small" href="/stories" data-testid="link-story-library">Кітапханаға өту <ArrowRight className="icon" /></Link>}</div>
    </section>
    <div className="section-row"><h2>Бүгін қай жерден бастаймыз?</h2><Link className="text-link" href="/progress" data-testid="link-see-progress">Жетістіктерім <ChevronRight className="icon" style={{ verticalAlign: 'middle' }} /></Link></div>
    <section className="journey-grid">
      <Link className="panel journey-card" href="/letters" data-testid="card-letters"><span className="deco">Әә</span><div className="eyebrow">01 · ТАНЫ</div><h3>42 әріпті үйрен</h3><p>Әр таңбаның дыбысын тыңдап, сөзден тап.</p><span className="text-link">Әріптерге өту →</span></Link>
      <Link className="panel journey-card" href="/syllables" data-testid="card-syllables"><span className="deco">ба</span><div className="eyebrow">02 · ҚҰРА</div><h3>Буынмен оқы</h3><p>Сөзді бөліктерге бөліп, біртіндеп оқы.</p><span className="text-link">Жаттығу бастау →</span></Link>
      <Link className="panel journey-card" href="/stories" data-testid="card-stories"><span className="deco">оқы</span><div className="eyebrow">03 · ОҚЫ</div><h3>Шағын әңгімелер</h3><p>Өзіңе ұнаған тақырыпты таңдап, дауыстап оқы.</p><span className="text-link">Кітапхананы ашу →</span></Link>
    </section>
    <div className="section-row"><h2>Оқу жолың</h2><span className="pill"><Flame className="icon" /> Күн сайынғы із</span></div>
    {progress.isLoading ? <div className="stats-row">{[1,2,3,4].map((n) => <div key={n} className="panel stat"><div className="skeleton" style={{ width: 55, height: 27 }} /><div className="skeleton" style={{ width: 88, height: 12, marginTop: 10 }} /></div>)}</div> : progress.isError ? <ErrorState retry={() => void progress.refetch()} /> : <section className="stats-row">
      <div className="panel stat"><strong>{summary?.completedLetters ?? 0}<span style={{ fontSize: 15, color: '#94a098' }}> / {summary?.totalLetters ?? 42}</span></strong><span>үйренген әріп</span></div>
      <div className="panel stat"><strong>{summary?.completedWords ?? 0}</strong><span>оқылған сөз</span></div>
      <div className="panel stat"><strong>{summary?.completedStories ?? 0}<span style={{ fontSize: 15, color: '#94a098' }}> / {summary?.totalStories ?? 100}</span></strong><span>оқылған әңгіме</span></div>
      <div className="panel stat"><strong>{summary?.streakDays ?? 0}<span style={{ fontSize: 15, color: '#94a098' }}> күн</span></strong><span>қатарынан оқыдың</span></div>
    </section>}
    <div className="section-row"><h2>Сынақ мерзімі</h2><Link className="text-link" href="/subscription" data-testid="link-manage-plan">Толығырақ →</Link></div>
    <section className="panel" style={{ padding: 21, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
      <div><span className="pill gold"><Sparkles className="icon" /> {subscription.data?.status === 'trialing' ? '7 КҮН ТЕГІН СЫНАҚ' : 'ОҚУ ЖОСПАРЫ'}</span><p style={{ margin: '10px 0 0', color: '#6d7a73', fontSize: 13 }}>Әріптер, буындар және 100 қысқа әңгіме — бір жерде.</p></div>
      <Link className="btn btn-secondary" href="/subscription" data-testid="link-subscription-home">Жоспарды көру <ArrowRight className="icon" /></Link>
    </section>
    {showTodayText && story && <div className="reader-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowTodayText(false); }}><article className="reader-modal" role="dialog" aria-modal="true" aria-labelledby="today-title"><div className="modal-top"><div><span className="pill coral"><CalendarDays className="icon" /> БҮГІНГІ ӘҢГІМЕ</span><h2 id="today-title" style={{ margin: '14px 0 0', fontSize: 30 }}>{story.title}</h2></div><button className="btn btn-quiet btn-icon" aria-label="Жабу" onClick={() => setShowTodayText(false)} data-testid="button-close-today-story"><X className="icon" /></button></div><p style={{ whiteSpace: 'pre-line', fontSize: 18, lineHeight: 1.85, color: '#52635b', margin: '21px 0 24px' }}>{story.text}</p><div className="inline-actions"><button className="btn btn-secondary" onClick={() => speak(story.text)} data-testid="button-play-today-story"><Headphones className="icon" /> Тыңдау</button><button className="btn btn-primary" disabled={record.isPending} onClick={() => record.mutate({ data: { itemType: 'story', itemId: story.id } }, { onSuccess: () => { setShowTodayText(false); } })} data-testid="button-complete-today-story"><Check className="icon" /> Оқып бітірдім</button></div>{record.isError && <p role="alert" style={{ color: '#a84439', marginTop: 12 }}>Нәтижені сақтау мүмкін болмады. Қайталап көр.</p>}</article></div>}
    <FooterNote />
  </main></PageFrame>;
}

function LettersPage() {
  const query = useGetLetters();
  const progress = useGetProgress();
  const record = useRecordProgress();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const letters = (query.data || []) as Letter[];
  const selected = letters.find((item) => item.id === selectedId);
  const completed = progress.data as Summary | undefined;
  const [repeatCount, setRepeatCount] = useState(1);
  function playLetter() {
    if (!selected) return;
    void speak(Array.from({ length: repeatCount }, () => selected.sound || selected.uppercase).join('… '), 0.8);
  }
  return <PageFrame><main className="page-wrap">
    <PageHead eyebrow="1-БӨЛІМ · ТАНЫП ҮЙРЕН" title="Қазақ әліпбиі"><p className="lede">Әріпті таңда — дыбысын тыңда, мысал сөзді оқы.</p></PageHead>
    {query.isLoading ? <div className="letter-grid">{Array.from({ length: 42 }, (_, index) => <div key={index} className="skeleton" style={{ height: 68 }} />)}</div> : query.isError ? <ErrorState retry={() => void query.refetch()} /> : letters.length === 0 ? <EmptyState title="Әріптер әзірге көрінбейді" detail="Біраздан кейін қайта кіріп көріңіз." /> : <div className="letters-layout">
      <section className="panel letter-board"><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '0 1px 16px' }}><strong>{letters.length} әріп</strong><span style={{ color: '#7d8a83', fontSize: 12 }}>{completed?.completedLetters ?? 0} таныс</span></div><div className="letter-grid" aria-label="Қазақ әліпбиі">{letters.map((letter) => <button key={letter.id} className={`letter-tile ${selectedId === letter.id ? 'selected' : ''}`} onClick={() => { setSelectedId(letter.id); void speak(`${letter.sound} ${letter.exampleWord}`, 0.8); }} aria-pressed={selectedId === letter.id} aria-label={`${letter.uppercase}, ${letter.lowercase} әрпі`} data-testid={`button-letter-${letter.id}`}><strong>{letter.uppercase}</strong><span>{letter.lowercase}</span></button>)}</div></section>
      <aside className="panel letter-detail" aria-live="polite">{selected ? <>
        <div className="eyebrow">ТАҢДАЛҒАН ӘРІП</div><div className="letter-glyph">{selected.uppercase}<span style={{ color: '#df896a' }}>{selected.lowercase}</span></div>
        <div className="sound-row"><span>Дыбысы</span><strong>{selected.sound || selected.uppercase}</strong></div>
        <div className="sound-row"><span>Мысал сөз</span><strong>{selected.exampleWord}</strong></div>
        <div className="sound-row"><span>Мағынасы</span><strong>{selected.exampleMeaning}</strong></div>
        <div className="inline-actions" style={{ marginTop: 17 }}><button className="btn btn-secondary" onClick={playLetter} data-testid="button-repeat-letter"><Volume2 className="icon" /> Қайталау ×{repeatCount}</button><button className="btn btn-quiet btn-icon" aria-label="Қайталау санын өзгерту" onClick={() => setRepeatCount((value) => value === 3 ? 1 : value + 1)} data-testid="button-change-repeat"><RotateCcw className="icon" /></button></div>
        <button className="btn btn-primary" style={{ width: '100%', marginTop: 12 }} disabled={record.isPending} onClick={() => record.mutate({ data: { itemType: 'letter', itemId: selected.id } }, { onSuccess: () => void queryClient.invalidateQueries({ queryKey: getGetProgressQueryKey() }) })} data-testid="button-complete-letter"><Check className="icon" /> {record.isPending ? 'Сақталып жатыр…' : 'Үйрендім'}</button>
        {record.isError && <p role="alert" style={{ color: '#a84439', fontSize: 12, margin: '10px 0 0' }}>Белгіні сақтау мүмкін болмады. Қайта байқап көр.</p>}
      </> : <div className="empty-state"><div className="letter-glyph" style={{ opacity: .25 }}>Әә</div><strong>Әріпті таңда</strong><span>Дыбысын автоматты түрде қосамыз.</span></div>}</aside>
    </div>}
    <FooterNote />
  </main></PageFrame>;
}

function SyllablesPage() {
  const query = useGetWords();
  const record = useRecordProgress();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeSyllable, setActiveSyllable] = useState(-1);
  const [isReading, setIsReading] = useState(false);
  const words = (query.data || []) as Word[];
  const selected = words.find((item) => item.id === selectedId) || words[0];
  const readingRef = useRef(false);
  useEffect(() => () => { readingRef.current = false; stopSpeech(); }, []);
  async function readWord() {
    if (!selected) return;
    stopSpeech();
    readingRef.current = true;
    setIsReading(true); setActiveSyllable(0);
    for (let index = 0; index < selected.syllables.length; index += 1) {
      if (!readingRef.current) return;
      setActiveSyllable(index);
      await speak(selected.syllables[index], 0.75);
    }
    if (readingRef.current) {
      readingRef.current = false;
      setIsReading(false);
      setActiveSyllable(-1);
    }
  }
  function stopReading() {
    readingRef.current = false; stopSpeech(); setIsReading(false); setActiveSyllable(-1);
  }
  return <PageFrame><main className="page-wrap">
    <PageHead eyebrow="2-БӨЛІМ · БУЫНҒА БӨЛ" title="Буынмен оқу"><p className="lede">Сөзді буын-буынмен оқы. Әр бөлікке түртіп, дыбысын бөлек тыңда.</p></PageHead>
    {query.isLoading ? <LoadingState label="Сөздер жүктелуде" /> : query.isError ? <ErrorState retry={() => void query.refetch()} /> : words.length === 0 ? <EmptyState title="Жаттығу сөздері әлі жоқ" detail="Кейінірек қайта келіп көріңіз." /> : <div className="word-layout">
      <section className="panel word-practice">
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}><span className="pill"><Sparkles className="icon" /> БУЫН ЖАТТЫҒУЫ</span><span style={{ color: '#6d8176', fontSize: 12, fontWeight: 700 }}>{words.findIndex((item) => item.id === selected?.id) + 1} / {words.length}</span></div>
        <div><div className="word-title">{selected?.word}</div><div className="syllable-line">{selected?.syllables.map((syllable, index) => <button key={`${selected.id}-${index}`} className={`syllable-chip ${activeSyllable === index ? 'active' : ''}`} onClick={() => { setActiveSyllable(index); void speak(syllable, 0.75); }} data-testid={`button-syllable-${index}`}>{syllable}</button>)}</div><p style={{ textAlign: 'center', color: '#74837b', margin: '16px 0 0', fontSize: 14 }}>{selected?.meaning}</p></div>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 9, flexWrap: 'wrap' }}>{isReading ? <button className="btn btn-secondary" onClick={stopReading} data-testid="button-stop-reading"><Pause className="icon" /> Тоқтату</button> : <button className="btn btn-primary" onClick={readWord} data-testid="button-read-word"><Play className="icon" /> Буынмен тыңдау</button>}<button className="btn btn-quiet" disabled={record.isPending} onClick={() => selected && record.mutate({ data: { itemType: 'word', itemId: selected.id } }, { onSuccess: () => void queryClient.invalidateQueries({ queryKey: getGetProgressQueryKey() }) })} data-testid="button-complete-word"><Check className="icon" /> Оқыдым</button></div>
        {record.isError && <div className="notice" role="alert">Оқу нәтижесін сақтау мүмкін болмады. Қайталап көріңіз.</div>}
      </section>
      <aside className="panel word-aside"><div className="eyebrow">ЖАТТЫҒУ СӨЗДЕРІ</div><h3 style={{ margin: '8px 0 0' }}>Келесі сөзді таңда</h3><div className="word-list">{words.map((word) => <button key={word.id} className={selected?.id === word.id ? 'active' : ''} onClick={() => { stopReading(); setSelectedId(word.id); }} data-testid={`button-word-${word.id}`}><span>{word.word}</span><small>{word.syllables.length} буын</small></button>)}</div></aside>
    </div>}
    <FooterNote />
  </main></PageFrame>;
}

function StoriesPage() {
  const [search, setSearch] = useState('');
  const [level, setLevel] = useState('');
  const [topic, setTopic] = useState('');
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const record = useRecordProgress();
  const params = useMemo(() => ({ ...(search.trim() ? { q: search.trim() } : {}), ...(level ? { level: Number(level) } : {}), ...(topic ? { topic } : {}) }), [search, level, topic]);
  const query = useGetStories(params);
  const stories = (query.data || []) as Story[];
  const topics = [...new Set(stories.map((story) => story.topic).filter(Boolean))];
  return <PageFrame><main className="page-wrap">
    <PageHead eyebrow="3-БӨЛІМ · МӘТІН ОҚЫ" title="Әңгімелер әлемі"><p className="lede">Қысқа мәтіндердің ішінен өзіңе қызық тақырып пен деңгей таңда.</p></PageHead>
    <div className="filters" style={{ marginBottom: 19 }}><label className="searchbar"><Search className="icon" /><span className="sr-only">Әңгіме іздеу</span><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Әңгіме атауын іздеу…" data-testid="input-story-search" /></label><label><span className="sr-only">Оқу деңгейі</span><select className="select" value={level} onChange={(event) => setLevel(event.target.value)} aria-label="Оқу деңгейі" data-testid="select-story-level"><option value="">Барлық деңгей</option>{[1,2,3,4,5].map((n) => <option key={n} value={n}>{n}-деңгей</option>)}</select></label><label><span className="sr-only">Тақырып</span><select className="select" value={topic} onChange={(event) => setTopic(event.target.value)} aria-label="Тақырып" data-testid="select-story-topic"><option value="">Барлық тақырып</option>{topics.includes(topic) ? null : topic && <option value={topic}>{topic}</option>}{topics.map((item) => <option key={item} value={item}>{item}</option>)}</select></label></div>
    <div style={{ display: 'flex', justifyContent: 'space-between', color: '#7a8981', fontSize: 12, margin: '0 1px 12px' }}><span>{query.isLoading ? 'Әңгімелер жүктелуде…' : `${stories.length} әңгіме`}</span><span>Барлығы 100 қысқа мәтін</span></div>
    {query.isLoading ? <div className="story-grid">{[1,2,3,4,5,6].map((n) => <div className="panel" key={n} style={{ padding: 20 }}><div className="skeleton" style={{ width: 40, height: 36 }} /><div className="skeleton" style={{ height: 17, width: '68%', marginTop: 19 }} /><div className="skeleton" style={{ height: 12, marginTop: 13 }} /><div className="skeleton" style={{ height: 12, width: '76%', marginTop: 8 }} /></div>)}</div> : query.isError ? <ErrorState retry={() => void query.refetch()} /> : stories.length === 0 ? <EmptyState title="Іздеуге сай әңгіме табылмады" detail="Сөзді өзгертіп немесе сүзгіні алып тастап көр." /> : <section className="story-grid">{stories.map((story, index) => <button key={story.id} className="panel story-card" onClick={() => setActiveStory(story)} data-testid={`card-story-${story.id}`} style={{ textAlign: 'left', color: 'inherit' }}><div style={{ display: 'flex', justifyContent: 'space-between' }}><span className="story-number">{String(index + 1).padStart(2, '0')}</span><span className="pill gold">{story.level}-деңгей</span></div><h3>{story.title}</h3><p>{story.text}</p><div className="story-meta"><span>{story.topic}</span><span>ОҚУ <ArrowRight className="icon" style={{ width: 14, verticalAlign: 'middle' }} /></span></div></button>)}</section>}
    {activeStory && <div className="reader-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setActiveStory(null); }}><article className="reader-modal" role="dialog" aria-modal="true" aria-labelledby="reader-title"><div className="modal-top"><div><span className="pill gold">{activeStory.level}-деңгей · {activeStory.topic}</span><h2 id="reader-title" style={{ margin: '15px 0 8px', fontSize: 30 }}>{activeStory.title}</h2></div><button className="btn btn-quiet btn-icon" onClick={() => setActiveStory(null)} aria-label="Жабу" data-testid="button-close-reader"><X className="icon" /></button></div><p style={{ whiteSpace: 'pre-line', fontSize: 18, lineHeight: 1.85, color: '#52635b', margin: '21px 0 24px' }}>{activeStory.text}</p><div className="inline-actions"><button className="btn btn-secondary" onClick={() => speak(activeStory.text, .84)} data-testid="button-listen-story"><Headphones className="icon" /> Тыңдау</button><button className="btn btn-primary" disabled={record.isPending} onClick={() => record.mutate({ data: { itemType: 'story', itemId: activeStory.id } }, { onSuccess: () => { setActiveStory(null); void queryClient.invalidateQueries({ queryKey: getGetProgressQueryKey() }); } })} data-testid="button-complete-story"><Check className="icon" /> Оқып бітірдім</button></div>{record.isError && <p role="alert" style={{ color: '#a84439', marginTop: 12 }}>Нәтижені сақтау мүмкін болмады. Қайталап көр.</p>}</article></div>}
    <FooterNote />
  </main></PageFrame>;
}

function ProgressPage() {
  const query = useGetProgress();
  const summary = query.data as Summary | undefined;
  const letterPercent = summary?.totalLetters ? Math.min(100, Math.round(summary.completedLetters / summary.totalLetters * 100)) : 0;
  const storyPercent = summary?.totalStories ? Math.min(100, Math.round(summary.completedStories / summary.totalStories * 100)) : 0;
  return <PageFrame><main className="page-wrap"><PageHead eyebrow="СЕНІҢ ОҚУ ЖОЛЫҢ" title="Жетістіктер"><p className="lede">Күн сайынғы машығың мен үйренгендерің осы жерде жиналады.</p></PageHead>
    {query.isLoading ? <LoadingState /> : query.isError ? <ErrorState retry={() => void query.refetch()} /> : !summary ? <EmptyState title="Әзірге дерек жоқ" detail="Бір әріп үйреніп, жолыңды баста." /> : <>
      <section className="stats-row"><div className="panel stat"><strong>{summary.completedLetters}<span style={{ fontSize: 15, color: '#94a098' }}> / {summary.totalLetters}</span></strong><span>әріп таныдың</span></div><div className="panel stat"><strong>{summary.completedWords}</strong><span>сөз оқыдың</span></div><div className="panel stat"><strong>{summary.completedStories}<span style={{ fontSize: 15, color: '#94a098' }}> / {summary.totalStories}</span></strong><span>әңгіме оқыдың</span></div><div className="panel stat"><strong>{summary.streakDays}<span style={{ fontSize: 15, color: '#94a098' }}> күн</span></strong><span>оқу кезегі</span></div></section>
      <div className="section-row"><h2>Алға жылжу</h2><span className="pill">Қазір {summary.level}-деңгей</span></div>
      <section className="metric-layout"><div className="panel metric-card"><div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><div><div className="eyebrow">ӘРІПТЕР</div><h3 style={{ margin: '8px 0' }}>Әліпбиді тану</h3></div><strong style={{ font: '800 27px var(--app-font-display)', color: '#28786a' }}>{letterPercent}%</strong></div><div className="progress-track"><div className="progress-fill" style={{ width: `${letterPercent}%` }} /></div><p style={{ color: '#7c8981', fontSize: 12, margin: '10px 0 0' }}>{summary.completedLetters} / {summary.totalLetters} әріп</p></div>
      <div className="panel metric-card"><div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><div><div className="eyebrow">ӘҢГІМЕЛЕР</div><h3 style={{ margin: '8px 0' }}>Оқылған мәтіндер</h3></div><strong style={{ font: '800 27px var(--app-font-display)', color: '#c8795a' }}>{storyPercent}%</strong></div><div className="progress-track"><div className="progress-fill" style={{ width: `${storyPercent}%`, background: '#df896a' }} /></div><p style={{ color: '#7c8981', fontSize: 12, margin: '10px 0 0' }}>{summary.completedStories} / {summary.totalStories} әңгіме</p></div></section>
      <div className="section-row"><h2>Келесі қадам</h2></div><div className="panel trial-banner"><div><span className="pill coral"><Flame className="icon" /> {summary.streakDays ? `${summary.streakDays} КҮН ҮЗБЕЙ` : 'БҮГІН БАСТА'}</span><h3 style={{ margin: '13px 0 7px', fontSize: 20 }}>Кішкентай қадамдар үлкен оқуға жеткізеді.</h3><p style={{ color: '#6b7d73', margin: 0 }}>Бүгін бір әріп немесе бір шағын әңгіме оқып көр.</p></div><Link className="btn btn-primary" href="/letters" data-testid="link-progress-practice">Жаттығуды жалғастыру <ArrowRight className="icon" /></Link></div>
    </>}
    <FooterNote />
  </main></PageFrame>;
}

function ProfileUser() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const fullName = user?.fullName || user?.primaryEmailAddress?.emailAddress || 'Оқырман';
  return <section className="panel profile-info"><div style={{ display: 'flex', gap: 15, alignItems: 'center' }}><div className="avatar">{fullName.slice(0,1).toLocaleUpperCase('kk')}</div><div><div className="eyebrow">ОҚЫРМАН</div><h2 style={{ margin: '6px 0' }}>{fullName}</h2><span style={{ color: '#77867f', fontSize: 12 }}>{user?.primaryEmailAddress?.emailAddress}</span></div></div><button className="btn btn-outline small" style={{ marginTop: 23 }} onClick={() => void signOut({ redirectUrl: basePath || '/' })} data-testid="button-sign-out">Аккаунттан шығу</button></section>;
}

function ProfilePage({ clerkEnabled }: { clerkEnabled: boolean }) {
  const subscription = useGetSubscription();
  const info = subscription.data as Subscription | undefined;
  const statusLabel = info?.status === 'trialing' ? 'Тегін сынақ белсенді' : info?.status === 'active' ? 'Белсенді' : info?.status === 'expired' ? 'Сынақ мерзімі аяқталған' : info?.status === 'cancelled' ? 'Тоқтатылған' : 'Күйі анықталмады';
  return <PageFrame><main className="page-wrap"><PageHead eyebrow="ЖЕКЕ БӨЛІМ" title="Профиль"><p className="lede">Оқу күйің мен аккаунт туралы ақпарат.</p></PageHead>
    <div className="profile-card">{clerkEnabled ? <ProfileUser /> : <section className="panel profile-info"><div style={{ display: 'flex', gap: 15, alignItems: 'center' }}><div className="avatar">О</div><div><div className="eyebrow">ҚОНАҚ РЕЖИМІ</div><h2 style={{ margin: '6px 0' }}>Оқырман</h2><span style={{ color: '#77867f', fontSize: 12 }}>Оқу барысы осы құрылғының жеке профилінде сақталады.</span></div></div><Link className="btn btn-primary" style={{ marginTop: 24 }} href="/sign-in" data-testid="link-profile-signin"><LogIn className="icon" /> Аккаунтқа кіру</Link></section>}
      <section className="panel profile-info"><div className="eyebrow">ЖАЗЫЛЫМ КҮЙІ</div>{subscription.isLoading ? <div className="skeleton" style={{ width: 190, height: 28, marginTop: 13 }} /> : subscription.isError ? <div style={{ marginTop: 15 }}><ErrorState retry={() => void subscription.refetch()} /></div> : <><h2 style={{ margin: '10px 0' }}>{statusLabel}</h2><p style={{ color: '#77867f', fontSize: 13, lineHeight: 1.6 }}>7 күндік сынақ мерзімі, одан кейін айына 1 990 ₸.</p>{info?.trialEndsAt && <p style={{ color: '#52645b', fontSize: 13 }}>Сынақтың соңғы күні: <strong>{new Date(info.trialEndsAt).toLocaleDateString('kk-KZ')}</strong></p>}<Link className="btn btn-secondary" href="/subscription" data-testid="link-profile-subscription">Жазылымды басқару <ArrowRight className="icon" /></Link></>}</section>
    </div>
    <div className="section-row"><h2>Оқу бөлімдері</h2></div><div className="panel" style={{ overflow: 'hidden' }}>{navItems.slice(1).map(({ href, label, icon: Icon }, index) => <Link key={href} href={href} className="sound-row" style={{ padding: '16px 20px', borderTop: index ? '1px solid #ece6dc' : 0 }} data-testid={`link-profile-${href.replace('/', '')}`}><span style={{ display: 'flex', gap: 10, alignItems: 'center', color: '#52645b' }}><Icon className="icon" style={{ color: '#347d6e' }} />{label}</span><ChevronRight className="icon" /></Link>)}</div><FooterNote /></main></PageFrame>;
}

function SubscriptionPage() {
  const query = useGetSubscription();
  const sub = query.data as Subscription | undefined;
  const statusLabel = sub?.status === 'trialing' ? 'Сынақ мерзімі белсенді' : sub?.status === 'active' ? 'Жазылым белсенді' : sub?.status === 'expired' ? 'Сынақ аяқталған' : sub?.status === 'cancelled' ? 'Жазылым тоқтатылған' : 'Жазылым ақпараты';
  const daysLeft = sub?.trialEndsAt ? Math.max(0, Math.ceil((new Date(sub.trialEndsAt).getTime() - Date.now()) / 86400000)) : null;
  return <PageFrame><main className="page-wrap"><PageHead eyebrow="ЖАЗЫЛЫМ" title="Оқу жолын жалғастыр"><p className="lede">Алғашқы 7 күн тегін. Одан кейін жоспар ай сайын жаңартылады.</p></PageHead>
    {query.isLoading ? <LoadingState /> : query.isError ? <ErrorState retry={() => void query.refetch()} /> : <><section className="panel trial-banner"><div><span className="pill gold"><Sparkles className="icon" /> 7 КҮН ТЕГІН</span><h2 style={{ margin: '14px 0 7px' }}>{statusLabel}</h2><p style={{ margin: 0, color: '#687b72' }}>{daysLeft !== null && sub?.status === 'trialing' ? `Сынақтың аяқталуына ${daysLeft} күн қалды.` : 'Әріптен әңгімеге дейінгі оқу материалдары.'}</p></div><div className="price">{(sub?.monthlyPrice ?? 1990).toLocaleString('kk-KZ')} <small>{sub?.currency || 'KZT'} / ай</small></div></section>
    <section className="metric-layout" style={{ marginTop: 18 }}><div className="panel metric-card"><div className="eyebrow">ЖОСПАРДА БАР</div><h2 style={{ margin: '10px 0' }}>Оқуға қажеттінің бәрі</h2><ul className="feature-list"><li><Check className="icon" style={{ color: '#34806e' }} /> Қазақ әліпбиінің 42 әрпі</li><li><Check className="icon" style={{ color: '#34806e' }} /> Буынға бөліп оқу жаттығулары</li><li><Check className="icon" style={{ color: '#34806e' }} /> Іздеуге болатын 100 қысқа әңгіме</li><li><Check className="icon" style={{ color: '#34806e' }} /> Жеке оқу жетістіктері</li></ul></div>
    <div className="panel metric-card"><div className="eyebrow">ТӨЛЕМ ТУРАЛЫ</div><h2 style={{ margin: '10px 0' }}>1990 ₸ / ай</h2><p style={{ color: '#728078', fontSize: 14, lineHeight: 1.65 }}>Сынақ мерзімі аяқталған соң ай сайын төленеді. Төлем әдісі мен жазылымды басқару аккаунт баптауларында қолжетімді болады.</p>{sub?.nextPaymentAt && <p style={{ color: '#52645b', fontSize: 13 }}>Келесі төлем: <strong>{new Date(sub.nextPaymentAt).toLocaleDateString('kk-KZ')}</strong></p>}<div className="notice" style={{ marginTop: 18 }}>Төлемді іске қосу бұл ортада әлі қолжетімсіз. Жазылым белсенді болмаса, төлем жасалды деп көрсетілмейді.</div></div></section>
    <div className="section-row"><h2>Күй туралы</h2></div><section className="panel" style={{ padding: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 15, flexWrap: 'wrap' }}><div><strong>{statusLabel}</strong><p style={{ color: '#78857e', fontSize: 12, margin: '6px 0 0' }}>{sub?.trialStartedAt ? `Басталған күні: ${new Date(sub.trialStartedAt).toLocaleDateString('kk-KZ')}` : 'Дерек берілгенде мерзімі осында көрсетіледі.'}</p></div><Link className="btn btn-secondary" href="/profile" data-testid="link-plan-profile">Профильге өту <ArrowRight className="icon" /></Link></section></>}
    <FooterNote /></main></PageFrame>;
}

function AdminPage() {
  const query = useGetAdminStories();
  const create = useCreateStory();
  const update = useUpdateStory();
  const remove = useDeleteStory();
  const qc = useQueryClient();
  const stories = (query.data || []) as Story[];
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [title, setTitle] = useState('');
  const [topic, setTopic] = useState('');
  const [level, setLevel] = useState(1);
  const [text, setText] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [message, setMessage] = useState('');
  const selected = stories.find((item) => item.id === selectedId);
  function selectStory(story: Story) {
    setSelectedId(story.id); setIsNew(false); setTitle(story.title); setTopic(story.topic); setLevel(story.level); setText(story.text); setMessage('');
  }
  function startCreate() {
    setSelectedId(null); setIsNew(true); setTitle(''); setTopic(''); setLevel(1); setText(''); setMessage('');
  }
  async function saveStory(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const payload = { title: title.trim(), topic: topic.trim(), level, text: text.trim() };
    if (!payload.title || !payload.topic || !payload.text) { setMessage('Атауы, тақырыбы және мәтіні бос болмауы керек.'); return; }
    setMessage('');
    const options = { onSuccess: () => { void qc.invalidateQueries({ queryKey: getGetAdminStoriesQueryKey() }); void qc.invalidateQueries({ queryKey: getGetStoriesQueryKey() }); setMessage('Әңгіме сақталды.'); setIsNew(false); } };
    if (isNew) create.mutate({ data: payload }, options);
    else if (selectedId) update.mutate({ id: selectedId, data: payload }, options);
  }
  function deleteSelected() {
    if (!selectedId) return;
    remove.mutate({ id: selectedId }, { onSuccess: () => { void qc.invalidateQueries({ queryKey: getGetAdminStoriesQueryKey() }); void qc.invalidateQueries({ queryKey: getGetStoriesQueryKey() }); setSelectedId(null); setDeleteConfirm(false); setMessage('Әңгіме жойылды.'); setTitle(''); setTopic(''); setText(''); } });
  }
  const saving = create.isPending || update.isPending;
  const protectedError = query.isError && ((query.error as { response?: { status?: number } })?.response?.status === 401 || (query.error as { response?: { status?: number } })?.response?.status === 403);
  return <PageFrame><main className="page-wrap"><PageHead eyebrow="МАЗМҰН БАСҚАРУ" title="Әңгімелерді басқару"><p className="lede">Әңгіме қосу, мәтінін жаңарту және кітапханадан жою.</p></PageHead>
    {query.isLoading ? <LoadingState label="Әңгімелер тізімі жүктелуде" /> : protectedError ? <section className="panel empty-state"><LockKeyhole className="icon" style={{ margin: '0 auto 13px', color: '#ba7658', width: 28, height: 28 }} /><strong>Әкімшіге ғана арналған бөлім</strong><span>Бұл мазмұнды басқару үшін әкімші рұқсаты қажет. API қолжетімділікті өзі тексереді.</span><Link className="btn btn-secondary" href="/" style={{ margin: '20px auto 0' }} data-testid="link-admin-home">Басты бетке қайту</Link></section> : query.isError ? <ErrorState retry={() => void query.refetch()} message="Әкімші мазмұнын алу мүмкін болмады." /> : <div className="admin-layout">
      <aside className="panel admin-list"><div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, padding: '4px 4px 12px' }}><strong>{stories.length} әңгіме</strong><button className="btn btn-primary small" onClick={startCreate} data-testid="button-new-story"><Plus className="icon" /> Жаңа</button></div>{stories.length === 0 ? <div className="empty-state"><strong>Тізім бос</strong><span>Алғашқы әңгімеңді қос.</span></div> : stories.map((story) => <button key={story.id} className={`admin-item ${selectedId === story.id ? 'active' : ''}`} onClick={() => selectStory(story)} data-testid={`button-edit-story-${story.id}`}><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{story.title}</span><small>{story.level}-деңгей</small></button>)}</aside>
      <form className="panel admin-form" onSubmit={saveStory}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}><div><div className="eyebrow">{isNew ? 'ЖАҢА МӘТІН' : selected ? 'МӘТІНДІ ӨҢДЕУ' : 'ӘҢГІМЕ ТАҢДАЛМАҒАН'}</div><h2 style={{ margin: '7px 0 0' }}>{isNew ? 'Әңгіме қосу' : selected ? selected.title : 'Әңгіме таңда'}</h2></div>{selected && <button type="button" className="btn btn-danger small" onClick={() => setDeleteConfirm(true)} data-testid="button-delete-story"><Trash2 className="icon" /> Жою</button>}</div>
      {(selected || isNew) ? <>
        <label className="field">Әңгіме атауы<input value={title} onChange={(event) => setTitle(event.target.value)} required maxLength={140} placeholder="Мысалы: Кішкентай қоян" data-testid="input-admin-title" /></label>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}><label className="field">Тақырып<input value={topic} onChange={(event) => setTopic(event.target.value)} required placeholder="Табиғат, отбасы…" data-testid="input-admin-topic" /></label><label className="field">Деңгей<select value={level} onChange={(event) => setLevel(Number(event.target.value))} data-testid="select-admin-level">{[1,2,3,4,5].map((n) => <option key={n} value={n}>{n}-деңгей</option>)}</select></label></div>
        <label className="field">Мәтін<textarea value={text} onChange={(event) => setText(event.target.value)} required placeholder="Қысқа әңгіме мәтіні…" data-testid="textarea-admin-text" /></label>
        {message && <div className="notice" role="status">{message}</div>}{(create.isError || update.isError || remove.isError) && <div className="error-box" role="alert">Әрекет орындалмады. Мәліметті тексеріп, қайта байқап көріңіз.</div>}
        <div className="form-actions"><button type="button" className="btn btn-quiet" onClick={() => { setIsNew(false); setSelectedId(null); setMessage(''); }} data-testid="button-cancel-edit">Болдырмау</button><button type="submit" className="btn btn-primary" disabled={saving} data-testid="button-save-story"><Check className="icon" /> {saving ? 'Сақталып жатыр…' : 'Сақтау'}</button></div>
      </> : <div className="empty-state"><Pencil className="icon" style={{ margin: '0 auto 10px', color: '#438778' }} /><strong>Мәтінді таңда немесе жаңасын қос</strong><span>Сол жақ тізімнен әңгіме таңдап түзет.</span></div>}
      </form>
    </div>}
    {deleteConfirm && <div className="reader-backdrop" role="presentation"><div className="reader-modal" role="alertdialog" aria-modal="true" aria-labelledby="delete-title" style={{ maxWidth: 430 }}><div className="modal-top"><div><div className="eyebrow">РАСТАУ</div><h2 id="delete-title" style={{ marginTop: 9 }}>Әңгімені жоямыз ба?</h2></div><button className="btn btn-quiet btn-icon" onClick={() => setDeleteConfirm(false)} aria-label="Жабу" data-testid="button-close-delete"><X className="icon" /></button></div><p style={{ color: '#6f7e76', lineHeight: 1.6 }}>«{selected?.title}» әңгімесі кітапханадан алынады. Бұл әрекетті кейін қайтару мүмкін емес.</p><div className="inline-actions" style={{ justifyContent: 'flex-end' }}><button className="btn btn-quiet" onClick={() => setDeleteConfirm(false)} data-testid="button-cancel-delete">Болдырмау</button><button className="btn btn-danger" disabled={remove.isPending} onClick={deleteSelected} data-testid="button-confirm-delete"><Trash2 className="icon" /> Жою</button></div></div></div>}
    <FooterNote />
  </main></PageFrame>;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    socialButtonsPlacement: 'top' as const,
    socialButtonsVariant: 'blockButton' as const,
  },
  variables: {
    colorPrimary: '#267b6c',
    colorForeground: '#24433d',
    colorMutedForeground: '#718079',
    colorDanger: '#b7463d',
    colorBackground: '#fffdf7',
    colorInput: '#fffdf7',
    colorInputForeground: '#24433d',
    colorNeutral: '#ddd8cc',
    fontFamily: 'DM Sans, sans-serif',
    borderRadius: '14px',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fffdf7] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'font-bold text-[#24433d]',
    headerSubtitle: 'text-[#718079]',
    socialButtonsBlockButtonText: 'font-semibold text-[#24433d]',
    formFieldLabel: 'font-semibold text-[#43564e]',
    footerActionLink: 'font-bold text-[#267b6c]',
    footerActionText: 'text-[#718079]',
    dividerText: 'text-[#718079]',
    identityPreviewEditButton: 'text-[#267b6c]',
    formFieldSuccessText: 'text-[#28786a]',
    alertText: 'text-[#a84439]',
    logoBox: 'rounded-xl',
    logoImage: 'rounded-lg',
    socialButtonsBlockButton: 'border-[#dedfd4] rounded-xl',
    formButtonPrimary: 'bg-[#267b6c] hover:bg-[#1d685c] rounded-xl',
    formFieldInput: 'bg-[#fffdf7] border-[#dedfd4] rounded-xl text-[#24433d]',
  },
};

function AuthPage({ mode, clerkEnabled }: { mode: 'sign-in' | 'sign-up'; clerkEnabled: boolean }) {
  const signIn = mode === 'sign-in';
  return <PageFrame><main className="auth-wrap"><section className="panel auth-frame"><div style={{ textAlign: 'center' }}><Brand /><div className="eyebrow" style={{ marginTop: 25 }}>{signIn ? 'ҚАЙТА КЕЛГЕНІҢЕ ҚУАНЫШТЫМЫЗ' : 'ОҚУ ЖОЛЫН БАСТА'}</div><h1 style={{ marginTop: 9 }}>{signIn ? 'Жалғастырайық.' : 'Бірге оқиық.'}</h1><p className="lede" style={{ margin: '10px auto 0' }}>{signIn ? 'Оқу жетістігіңді жалғастыру үшін аккаунтыңа кір.' : 'Оқу барысын сақтау үшін аккаунт аш.'}</p></div>{clerkEnabled ? <div className="auth-clerk">{signIn ? <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} appearance={clerkAppearance} /> : <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} appearance={clerkAppearance} />}</div> : <div className="notice" style={{ marginTop: 22 }}><CircleHelp className="icon" style={{ verticalAlign: 'middle', marginRight: 7 }} />Аккаунт қызметі қазір бапталуда. Оқу бөлімдерін қонақ ретінде пайдалана беруге болады.</div>}<p style={{ textAlign: 'center', color: '#718079', fontSize: 13, margin: '22px 0 0' }}>{signIn ? 'Аккаунтың жоқ па?' : 'Аккаунтың бар ма?'} <Link className="text-link" href={signIn ? '/sign-up' : '/sign-in'} data-testid="link-auth-switch">{signIn ? 'Тіркелу' : 'Кіру'}</Link></p></section></main></PageFrame>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  const authAvailable = Boolean(clerkPubKey);
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={HomePage} />
    <Route path="/letters" component={LettersPage} />
    <Route path="/syllables" component={SyllablesPage} />
    <Route path="/stories" component={StoriesPage} />
    <Route path="/progress" component={ProgressPage} />
    <Route path="/profile">{() => <ProfilePage clerkEnabled={authAvailable} />}</Route>
    <Route path="/subscription" component={SubscriptionPage} />
    <Route path="/admin" component={AdminPage} />
    <Route path="/sign-in/*?">{() => <AuthPage mode="sign-in" clerkEnabled={authAvailable} />}</Route>
    <Route path="/sign-up/*?">{() => <AuthPage mode="sign-up" clerkEnabled={authAvailable} />}</Route>
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function RoutedApplication() {
  const [, setLocation] = useLocation();
  if (!clerkPubKey) return <Router />;
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={clerkAppearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={kkKZ}
    routerPush={(path) => setLocation(stripBase(path))}
    routerReplace={(path) => setLocation(stripBase(path))}
  ><Router /></ClerkProvider>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={basePath}><RoutedApplication /></WouterRouter><Toaster /><AudioErrorNotice /></TooltipProvider></QueryClientProvider>;
}

export default App;