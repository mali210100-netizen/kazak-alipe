import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const storiesTable = pgTable("stories", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  level: integer("level").notNull(),
  topic: text("topic").notNull(),
  text: text("text").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const learnerProfilesTable = pgTable("learner_profiles", {
  learnerId: text("learner_id").primaryKey(),
  level: integer("level").notNull().default(1),
  trialStartedAt: timestamp("trial_started_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  trialEndsAt: timestamp("trial_ends_at", { withTimezone: true }).notNull(),
  subscriptionStatus: text("subscription_status").notNull().default("trialing"),
  nextPaymentAt: timestamp("next_payment_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const progressEventsTable = pgTable(
  "progress_events",
  {
    id: serial("id").primaryKey(),
    learnerId: text("learner_id").notNull(),
    itemType: text("item_type").notNull(),
    itemId: text("item_id").notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("progress_events_learner_item_unique").on(
      table.learnerId,
      table.itemType,
      table.itemId,
    ),
  ],
);

export type Story = typeof storiesTable.$inferSelect;
export type LearnerProfile = typeof learnerProfilesTable.$inferSelect;
export type ProgressEvent = typeof progressEventsTable.$inferSelect;